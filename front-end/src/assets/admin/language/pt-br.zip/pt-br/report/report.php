<?php
// Heading
$_['heading_title'] = 'Relatórios';

// Text
$_['text_success']  = 'Relatório modificado com sucesso!';
$_['text_list']     = 'Listando relatórios';
$_['text_type']     = 'Selecione o relatório';
$_['text_filter']   = 'Filtrar';