<?php
// Heading
$_['heading_title'] = 'Extensões';

// Text
$_['text_success']  = 'Você modificou a extensão com sucesso!';
$_['text_list']     = 'Lista de extensões';
$_['text_type']     = 'Selecione o tipo de extensão';
$_['text_filter']   = 'Filtrar';