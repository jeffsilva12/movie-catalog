<?php
// Heading
$_['heading_title']     = 'Relatórios';

// Text
$_['text_success']      = 'Relatório modificado com sucesso!';
$_['text_list']         = 'Listando relatórios';

// Column
$_['column_name']       = 'Relatório';
$_['column_status']     = 'Situação';
$_['column_sort_order'] = 'Posição';
$_['column_action']     = 'Ação';

// Error
$_['error_permission'] = 'Atenção: Você não tem permissão para modificar as extensões do tipo relatório!';