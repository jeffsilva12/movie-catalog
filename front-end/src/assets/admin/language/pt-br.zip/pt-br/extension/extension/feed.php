<?php
// Heading
$_['heading_title']    = 'Alimentadores';

// Text
$_['text_success']     = 'Alimentador modificado com sucesso!';
$_['text_list']        = 'Listando alimentadores';

// Column
$_['column_name']      = 'Alimentador';
$_['column_status']    = 'Situação';
$_['column_action']    = 'Ação';

// Error
$_['error_permission'] = 'Atenção: Você não tem permissão para modificar as extensões do tipo alimentador!';