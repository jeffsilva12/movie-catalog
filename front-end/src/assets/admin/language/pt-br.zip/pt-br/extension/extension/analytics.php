<?php
// Heading
$_['heading_title']    = 'Estatísticas';

// Text
$_['text_success']     = 'Estatística modificada com sucesso!';
$_['text_list']        = 'Listando Estatísticas';

// Column
$_['column_name']      = 'Estatística';
$_['column_status']    = 'Situação';
$_['column_action']    = 'Ação';

// Error
$_['error_permission'] = 'Atenção: Você não tem permissão para modificar as extensões do tipo estatística!';